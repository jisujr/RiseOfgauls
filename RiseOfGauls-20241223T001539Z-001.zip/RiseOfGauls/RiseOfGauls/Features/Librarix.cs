﻿namespace RiseOfGauls.Features;

public class Librarix : Core.Batimentix
{
    // Lib clss 
    public (string, string)?[][] Books { get; set; }

    // lib fun
    public Librarix() : base(100, 50, 20)
    { Books = new (string, string)?[6][]; for (int a = 0; a < 6; a++) // ethe main cost kita 100 nal fir vekhya jeh max durabily hundi ki nahi 
        { Books[a] = new (string, string)?[9];// ethe main bks vit strg kita 
        }
    }
    
    //GetbokGen fun
    public string GetBookGenre(string bookName)
    { foreach (var x in Books) // ethe main foreach kita 
        { foreach (var k in x) { if (k.HasValue && k.Value.Item1 == bookName) return k.Value.Item2; } // rt k.value
        } throw new GaulsException("E");// ethe trhw arg kita 
    }
    //Insertb fun 
    public void InsertBook(string name, string genre, int x, int y)
    { if (Books[x][y].HasValue || Haigyibook(name, genre)) throw new GaulsException("E"); // ethe main arg kita teh nal main hasvalue vi use kita 
        Books[x][y] = (name, genre); // ethe main bks likhyian
    }
    //Hagyi book fun 
    private bool Haigyibook(string m, string n) // ethe main new func banayi jerri 
    { foreach (var W in Books) // foreach kardi sarri bk vich 
        { foreach (var k in W) { if (k.HasValue && k.Value.Item1 == m && k.Value.Item2 == n) return true; } // rt true 
        } return false; // rt flse kita
    }
    //getmin fun 
    public int GetMinIndex((string, string)?[] array, int start)
    {
        int s = start; for (int z = start + 1; z < array.Length; z++) // fir main int kita sare int nal fir main lentgh use kiti
        { if (array[z].HasValue && array[z].Value.Item1.CompareTo(array[s].Value.Item1) < 0) s = z; } return s; // ethe main rt s kita fir sare valye madad kiti
    }
    //SortRow fun 
    public void SortRow(int row)
    {
        if (row < 0 || row >= Books.Length) throw new GaulsException("E"); // ethe main th arg kita fir main vekhya jeh rw nu 0 nal ho sakhda jan bks lenght nal
        for (int z = 0; z < Books[row].Length; z++) // ethe main for kita fir main z++ kita teh lgt use kita 
        { int x = GetMinIndex(Books[row], z); if (x == z) continue; // index x karke vir main bks use kita 
            var p = Books[row][z]; Books[row][z] = Books[row][x]; Books[row][x] = p; // fir var bks fr bks kita 
        }
    }
    // str, str sortLibrary 
    public (string, string)?[][] SortLibrary()
    { 
        var s = new System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<(string, string)>>(); // ethe main var s kiti sys nal 
        foreach (var w in Books) // fir main foreach kita 
        { foreach (var k in w) // fir main vapis foreach kita 
            { if (k.HasValue) { if (s.ContainsKey(k.Value.Item2) == false) s[k.Value.Item2] = new System.Collections.Generic.List<(string, string)>(); s[k.Value.Item2].Add(k.Value);
                } //ethe main if kita fir if kita 
            } 
        }foreach (var r in s.Keys) { s[r].Sort((a, b) => a.Item1.CompareTo(b.Item1)); // fir main foreach kita fir main change kita 
        } var y = new (string, string)?[Books.Length][]; int e = 0; // fir main var kita fir strg kita fir vi strg kita 
        foreach (var r in s) // fir foreach kita var kita 
        { if (e >= Books.Length) throw new GaulsException("E"); var n = r.Value; y[e] = new (string, string)?[n.Count];   // fir main nava string kita 
            for (int i = 0; i < n.Count; i++) y[e][i] = n[i]; e++; // fir main for kita 
        } return y; //rt y 
    }

}