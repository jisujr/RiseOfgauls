﻿namespace RiseOfGauls.Features;

public class Routix
{
    public string Name;// ethe vi 
    public List<Routix> AdjacencyList;
    private Dictionary<Routix, int> _distances; // ethe nam diti pehla 
// routix fun 
    public Routix(string name)
    { if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("err"); // ethe main if kita fir main name nal kita 
        Name = name; AdjacencyList = new List<Routix>(); _distances = new Dictionary<Routix, int>(); // ethe fir main sarey dic pahe 
    }
    // Addedge fun 

    public void AddEdge(Routix vertex, int distance)
    {
        if (vertex == null) throw new ArgumentNullException(nameof(vertex), "err"); // ethe main if kita fir main name nal kita 
        if (distance <= 0) throw new GaulsException("Distance must be greater than 0."); // ethe main fir exp kita fir thik veh 

        if (!AdjacencyList.Contains(vertex)) { AdjacencyList.Add(vertex); _distances[vertex] = distance; // ethe fir adjacy kita fir bas ayi hoya 
        }else { _distances[vertex] = distance; } // fir main else kita fir main ds fir fis hoya 
    }
    //removeEdge fun

    public void RemoveEdge(Routix vertex)
    {
        if (vertex == null) throw new ArgumentNullException(nameof(vertex), "err");// ethe main if kita fir main name nal kita
        if (!AdjacencyList.Contains(vertex)) throw new GaulsException("The vertex is not in the AdjacencyList");// ethe main fir exp kita fir thik veh 
        AdjacencyList.Remove(vertex); _distances.Remove(vertex); // ethe main rmv kita fir dis rmv kita 
    }
    //Getdis fun 

    public int GetDistance(Routix vertex)
    {
        if (vertex == null) throw new ArgumentNullException(nameof(vertex), "err");// ethe main if kita fir main name nal kita
        if (!_distances.ContainsKey(vertex)) { throw new GaulsException("The vertex is not in the AdjacencyList"); }// ethe main fir exp kita fir thik veh 
        return _distances[vertex]; // rt dis kita 
    }
}