﻿namespace RiseOfGauls.Features
{
    public class SellerixMan : Core.Batimentix
    {
        public Routix Start; 
        
        // sellerman fun 
        public SellerixMan(Routix start) : base(20, 20, 5)
        {
            if (start == null) throw new ArgumentNullException(nameof(start), "err"); // trhw arg kita 
            Start = start;  // ethe equal kita 
        }
        // Find pth fun 
        public bool FindPath(Routix destination)
        { if (destination == null) throw new ArgumentNullException(nameof(destination), "err"); List<Routix> d = new List<Routix>(); return LV(Start, destination, d);
        } // trh arg kita 
        
        //LV fun help karan vaste 
        private bool LV (Routix en, Routix t, List<Routix> d)
        {
            if (en == t) return true; d.Add(en); foreach (var b in en.AdjacencyList) //ethe main if kita fir true kita 
            { if (!d.Contains(b) && LV(b, t, d)) return true; // rt true 
            } return false; // rt false 
        }

       // thora path using dest 
        public List<Routix> ShortestPath(Routix destination, List<Routix> nodes)
        {
            if (destination == null) throw new ArgumentNullException(nameof(destination), "err"); // thrw arg kita 
            if (nodes == null || nodes.Count == 0) throw new ArgumentException("err", nameof(nodes)); // ethe vi thrw arg kita 
            
            Dictionary<Routix, int> c = new Dictionary<Routix, int>(); Dictionary<Routix, Routix> s = new Dictionary<Routix, Routix>(); List<Routix> d = new List<Routix>(nodes); // sareya dico nu dcl kita 
            foreach (var e in nodes) // ethe foreach kita 
            { c[e] = int.MaxValue; s[e] = null; // ethe int karke nukll kit 
            }
            c[Start] = 0; 
            while (d.Count > 0) // whle kita fir count nal compare kita 
            { Routix t = BV(d, c);
                if (t == null) break; if (t == destination) break;  // ethe main if kita 
                d.Remove(t);
                foreach (var b in t.AdjacencyList) // ethe main foreach kita 
                { int i = c[t] + t.GetDistance(b); // ethe main int kita 
                    if (i < c[b]) // ethe main if kita 
                    { c[b] = i; s[b] = t; } } } 
            List<Routix> h = new List<Routix>(); // ethe main ksit kita 
            Routix la = destination;
            while (la != null) // ethe main whle kita 
            { h.Add(la); la = s[la]; } h.Reverse(); 

            return h.Count == 0 || h[0] != Start ? new List<Routix>() : h; // ethe main rt kita  // teh strt nu ? ethda main 
        }

      // sareya to shoti dis
        private Routix BV(List<Routix> x, Dictionary<Routix, int> y)
        { Routix mv = null; int li = int.MaxValue; // ethe null kita 
            foreach (var loup in x) // ethe main for each kita 
            { if (y[loup] < li) // ethe main if kita 
                { mv = loup; li = y[loup]; // mv nal loup nu equal kita 
                } 
            } return mv; // rt mv 
        }

       // Dis fun
        public string Display()
        {
            List<Routix> d = new List<Routix>();
            List<string> t = new List<string>();
            LOVEINAIR(Start, d, t);
            return string.Join("\n", t); // rt string!;join 
        }

        // LOVE IN AIR FUN KITA UPER VALI FUN NU COMPLETE KARAN LYI 
        private void LOVEINAIR(Routix T, List<Routix> D, List<string> LT)
        {
            D.Add(T); foreach (var b in T.AdjacencyList) // ehte main foreahc kita fir main var kita 
            {
                string h = $"{T.Name} -> {b.Name}"; LT.Add(h); // str karke fir main kita 
                if (!D.Contains(b)) LOVEINAIR(b, D, LT); // if karke fir main contains kita 
                
            }
        }
    }
}


