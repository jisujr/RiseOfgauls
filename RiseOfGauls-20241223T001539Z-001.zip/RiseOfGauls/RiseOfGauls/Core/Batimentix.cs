﻿namespace RiseOfGauls.Core
{
    
    // Public class Batimentix func veh 
    public class Batimentix
    {
        /********************
         * ******************
         * ******************
         * ******************
         */
       
        protected long Cost; // ethe jadu koi bulding buy karni pehli vari , teh ethe galat nahi ho sakhda 
        protected int Durability; // ethe jadu vekhni ki bulding actual haigyi ki nahi 
        protected int MaxDurability; // ethe maximum time building da 
        protected int Level; // ethe ehnu 1 nal equal karna 
        protected int Population; // ethe building di habitation vekhni 
        
        
        // fun batimentix 
        public Batimentix(long cost, int maxDurability, int population)  // ਬਾਤੀਮਿੰਟਿਕ ਕਨਸਟਰਕਟਰ ਦੀ ਸ਼ੁਰੂਆਤ
        { if (cost < 0 || maxDurability < 0 || population < 0) throw new GaulsException(" Error in Bat ");  // ਗੌਲਸ ਐਕਸਪਸ਼ਨ ਉੱਠਾਓ
            Cost = cost; MaxDurability = maxDurability; Durability = maxDurability; Population = population; Level = 1;  // ਪੱਧਰ ਨੂੰ 1 ਤੇ ਸੈੱਟ ਕਰੋ
        }
        //  int Getlevel fun 
        public int GetLevel() { return Level; } // rt Level 

        // void setlevel fun 
        public void SetLevel(int level) // SetLevel ਮੈਥਡ ਦੀ ਸ਼ੁਰੂਆਤ
        { if (level < 0 || level > 10) throw new GaulsException("Error in Bat "); Level = level;// ਪੱਧਰ ਨੂੰ ਦਿੱਤੇ ਗਏ ਮੁੱਲ ਨਾਲ ਅਪਡੇਟ ਕਰੋ
        }
        // Long GetCost fun 
        public long GetCost() { return Cost * (long)Math.Ceiling(Math.Pow(Level, Level * 0.3)); // ਲਾਗਤ ਨੂੰ ਪੱਧਰ ਦੇ ਅਧਾਰ 'ਤੇ ਗਿਣਤੀ ਕਰਕੇ ਵਾਪਸੀ ਕਰੋ
        }
        //  Void Set cost 
        public void SetCost(long baseCost) { if (baseCost < 0) throw new GaulsException("Error in Bat "); Cost = baseCost;// ਮੁੱਲ ਨੂੰ ਪ੍ਰਾਰੰਭਿਕ ਲਾਗਤ ਨਾਲ ਅਪਡੇਟ ਕਰੋ
        }
        //int getdurabily fun 
        public int GetDurability() { return Durability; // rt dura
        }
        // setdura fun 
        public void SetDurability(int durability)
        { if (durability < 0) throw new GaulsException("Error In Bat "); Durability = Math.Min(durability, MaxDurability);  // ਟਿਕਾਊਤਾ ਨੂੰ ਅਧਿਕਤਮ ਟਿਕਾਊਤਾ ਨਾਲ ਘਟਾ ਕੇ ਸੈੱਟ ਕਰੋ
        }
        //getpopu fun 
        public int GetPopulation() { return Population; }// rt ppo
    }
}