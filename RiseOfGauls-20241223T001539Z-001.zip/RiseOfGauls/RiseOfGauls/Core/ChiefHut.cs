﻿namespace RiseOfGauls.Core;

public class ChiefHut : Batimentix
/* ethe main batimentix deh fields nu fir use kita */
{
    protected int FreePopulation; // ehnu main new banya 

    public ChiefHut() : base(10, 20, 5) { FreePopulation = 5; } // ਮੁਫਤ ਅਬਾਦੀ ਨੂੰ 5 'ਤੇ ਸੈੱਟ ਕਰੋ
    // int get free popu fun 
    public int GetFreePopulation() { return FreePopulation; } // rt popu 
    // SetFreePopu fun 
    public void SetFreePopulation(int freePopulation)
    { if (freePopulation > Population) throw new GaulsException("Error : Chiefhut "); FreePopulation = freePopulation;// ਮੁਫਤ ਅਬਾਦੀ ਨੂੰ Freepopulation 'ਤੇ ਸੈੱਟ ਕਰੋ
    }
    // setpopu fun 
    public void SetPopulation(int population)
    { if (population < 1) throw new GaulsException("Error : ik teh hona chahida"); FreePopulation += (population - Population); Population = population;// ਮੁਫਤ ਅਬਾਦੀ ਨੂੰ Freepopulation 'ਤੇ ਸੈੱਟ ਕਰੋ
    }
}