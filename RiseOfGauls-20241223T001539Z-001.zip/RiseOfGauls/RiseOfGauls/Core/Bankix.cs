﻿namespace RiseOfGauls.Core
{
    public class Bankix : Batimentix
    { 
        private Stack<int> _tradeHistory; private Random _random; private int _villageMoney;

        // bankix fun 
        public Bankix(Random random) : base(15, 15, 5)
        { _tradeHistory = new Stack<int>(); _random = random; _villageMoney = 25; // ਪਿੰਡ ਦੇ ਪੈਸੇ ਦੀ ਸ਼ੁਰੂਆਤ
        }
        // getVil Money fun 
        public int GetVillageMoney() { return _villageMoney; // ਪਿੰਡ ਦੇ ਪੈਸੇ ਨੂੰ ਵਾਪਸ ਕਰੋ
        }
        //setVill fun 
        public void SetVillageMoney(int money)
        { if (money < 0) throw new GaulsException("ERR"); _villageMoney = money;// ਪਿੰਡ ਦੇ ਪੈਸੇ ਨੂੰ ਸੈੱਟ ਕਰੋ
        }
        //Coll taxes 
        public int CollectTaxes(int population)
        { int l = _random.Next(1, 11); int t = Level * population * l; // ਟੈਕਸ ਦੀ ਗਿਣਤੀ: ਪੱਧਰ * ਆਬਾਦੀ * ਰੈਂਡਮ ਨੰਬਰ
            return t; // rt t 
        }
        // in Trd 
        public int Trade(int amount, int risk)
        {
            if (amount <= 0 || risk <= 0) throw new GaulsException("Error Trade");// ਜੇ ਰਕਮ ਅਤੇ ਖਤਰਾ 0 ਤੋਂ ਵੱਧ ਨਾ ਹੋਣ ਤਾਂ ਗਲਤੀ
            if (risk >= 100) throw new GaulsException("Error risk");// ਜੇ ਖਤਰਾ 100 ਤੋਂ ਵੱਧ ਹੋਵੇ ਤਾਂ ਗਲਤੀ
            
            int c = _random.Next(1, 101); int t; // ethe main int kita 
            if (c > risk)
            { int i = _random.Next(1, risk + 1); t = amount * i; // ਰਕਮ ਨੂੰ ਵੱਧ ਤੋਂ ਵੱਧ ਖਤਰੇ ਦੇ ਨਾਲ ਗੁਣਾ ਕਰੋ
            }else
            { int i = _random.Next(1, risk + 1); int s = amount * i; t = s;  // ਰਕਮ ਨੂੰ ਵੱਧ ਤੋਂ ਵੱਧ ਖਤਰੇ ਦੇ ਨਾਲ ਗੁਣਾ ਕਰੋ
                if (c <= risk) t = s * -1;// ਨੁਕਸਾਨ
            } return t; // rt t 
        }
        // trd History 
        public Stack<int> GetTradeHistory() { return _tradeHistory; } // ਵਪਾਰ ਇਤਿਹਾਸ ਨੂੰ ਵਾਪਸ ਕਰੋ

        // trd ad rd 
        public int TradeAndRecord(int amount, int risk)
        { int t = Trade(amount, risk); _tradeHistory.Push(t);// ਨਤੀਜੇ ਨੂੰ ਵਪਾਰ ਇਤਿਹਾਸ ਵਿੱਚ ਸ਼ਾਮਿਲ ਕਰੋ
            return t; // rt t 
        }
    }
}