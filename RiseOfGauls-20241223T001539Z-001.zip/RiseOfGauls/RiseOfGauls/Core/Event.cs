﻿namespace RiseOfGauls.Core
{
    public class Event
    {
        //Mess event da 
        public string Message; 

        // queue nal jada kujh milda 
        public Queue<(ENUM_EVENT, int)> Events; 

        //Evts main 
        public Event(string message, (ENUM_EVENT, int)[] array)
        { Message = message;
            Events = new Queue<(ENUM_EVENT, int)>(); // ਕੰਸਟ੍ਰੱਕਟਰ ਜੋ ਸੁਨੇਹਾ ਅਤੇ ਇਵੈਂਟਾਂ ਦੀ ਸੂਚੀ ਨੂੰ ਸ਼ੁਰੂ ਕਰਦਾ ਹੈ
            foreach (var em in array) { Events.Enqueue(em); }
        } // ਹਰ ਇੱਕ ਇਵੈਂਟ ਨੂੰ ਕਿਊ ਵਿੱਚ ਐਨਕਿਊ ਕਰਦਾ ਹੈ

        //mny evts 
        public void MoneyEvent(List<Batimentix> batiments, int value)
        { Bankix x = null; // ਬੈਟੀਮੈਂਟਿਸ ਦੀ ਸੂਚੀ ਤੋਂ Bankix ਨੂੰ ਲੱਭੋ
            for (int z = 0; z < batiments.Count; z++)
            { if (batiments[z] is Bankix) x = batiments[z] as Bankix; break; // ਜੇਕਰ ਕੋਈ Bankix ਨਹੀਂ ਮਿਲਦਾ ਤਾਂ ਇੱਕ ਗਲਤੀ ਫੈਲਾਓ
            } if (x == null) throw new GaulsException("Err "); x.SetVillageMoney(x.GetVillageMoney() + value); // ਇਵੈਂਟ ਦੇ ਮੁੱਲ ਨਾਲ ਗ੍ਰਾਮ ਦਾ ਪੈਸਾ ਅਪਡੇਟ ਕਰੋ
        }

        //pop evts
        public void PopulationEvent(List<Batimentix> batiments, int value)
        { ChiefHut y = null; //ਆਬਾਦੀ ਦੇ ਇਵੈਂਟ ਨੂੰ ਸੰਭਾਲਦਾ ਹੈ ਅਤੇ ਚੀਫਹੱਟ ਦੀ ਆਬਾਦੀ ਨੂੰ ਅਪਡੇਟ ਕਰਦਾ ਹੈ।
            for (int m = 0; m < batiments.Count; m++) // ਕਿਊ ਵਿੱਚ ਹਰ ਇਕ ਇਵੈਂਟ ਵਿੱਚ ਇਤਰਾ ਕਰਨ ਲਈ
            { if (batiments[m] is ChiefHut)
                { y = batiments[m] as ChiefHut; break; } // ਇਵੈਂਟ ਦੀ ਕਿਸਮ ਦੇ ਅਨੁਸਾਰ, ਸਬੰਧਤ ਇਵੈਂਟ ਹੈਂਡਲਰ ਮੈਥਡ ਨੂੰ ਕਾਲ ਕਰੋ
            } if (y == null) throw new GaulsException("Err"); y.SetPopulation(y.GetPopulation() + value); // ਇਵੈਂਟ ਦੇ ਮੁੱਲ ਨਾਲ ਗ੍ਰਾਮ ਦਾ ਪੈਸਾ ਅਪਡੇਟ ਕਰੋ
        }

        //Dura evts
        public void DurabilityEvent(List<Batimentix> batiments, int value)
        { for (int i = batiments.Count - 1; i >= 0; i--)// ethe main for kita si 
           { var g = batiments[i]; g.SetDurability(g.GetDurability() + value);// ਹਰ ਇੱਕ ਬਿਲਡਿੰਗ ਦੀ ਡਿਊਰੇਬਿਲਟੀ ਨੂੰ ਅਪਡੇਟ ਕਰੋ
               if (g.GetDurability() <= 0) { batiments.RemoveAt(i); // ਜੇਕਰ ਕਿਸੇ ਬਿਲਡਿੰਗ ਦੀ ਡਿਊਰੇਬਿਲਟੀ 0 ਜਾਂ ਉਸ ਤੋਂ ਘੱਟ ਹੋ ਜਾਂਦੀ ਹੈ ਤਾਂ ਉਸਨੂੰ ਸੂਚੀ ਤੋਂ ਹਟਾ ਦਿਓ
               }
           }
        }

        //Ext evts 
        public void ExecuteEvent(List<Batimentix> batiments)
        {
            foreach (var y in Events)
            { if (y.Item1 == ENUM_EVENT.MONEY) { MoneyEvent(batiments, y.Item2); } // ਇਵੈਂਟ ਦੀ ਕਿਸਮ ਦੇ ਅਨੁਸਾਰ, ਸਬੰਧਤ ਇਵੈਂਟ ਹੈਂਡਲਰ ਮੈਥਡ ਨੂੰ ਕਾਲ ਕਰੋ
                else if (y.Item1 == ENUM_EVENT.POPULATION) { PopulationEvent(batiments, y.Item2); } // ਮੈਥਡ ਜੋ ਸਾਰੇ ਇਵੈਂਟਾਂ ਦੇ ਨਤੀਜੇ ਨੂੰ ਦਿਖਾਉਂਦੀ ਹੈ
                else if (y.Item1 == ENUM_EVENT.DURABILITY) { DurabilityEvent(batiments, y.Item2); } // ethe main sme kita 
            }
        }

        //Dis bati
        public string Display(List<Batimentix> batiments)
        {
            var t = new List<string> { Message }; foreach (var x in Events) { // ਕਿਊ ਵਿੱਚ ਹਰ ਇਕ ਇਵੈਂਟ ਵਿੱਚ ਇਤਰਾ ਕਰਨ ਲਈ
                if (x.Item1 == ENUM_EVENT.MONEY)
                { MoneyEvent(batiments, x.Item2); // ਪੈਸਾ ਸਮਾਰਹੀਤ ਹਾਨੀ ਜਾਂ ਫਾਇਦੇ ਲਈ ਇਵੈਂਟ ਨੂੰ ਲਾਗੂ ਕਰੋ
                    if (x.Item2 < 0) t.Add("The village has lost " + Math.Abs(x.Item2) + " money"); else t.Add("The village has gained " + x.Item2 + " money"); // ਫਾਇਦਾ ਦਿਖਾਓ
                }else if (x.Item1 == ENUM_EVENT.POPULATION)
                { PopulationEvent(batiments, x.Item2); // ਆਬਾਦੀ ਦੀ ਸਮਾਰਹੀਤ ਦਾ ਇਵੈਂਟ ਲਾਗੂ ਕਰੋ
                    if (x.Item2 < 0) t.Add("The village has lost " + Math.Abs(x.Item2) + " population"); else t.Add("The village has gained " + x.Item2 + " population"); // ਫਾਇਦਾ ਦਿਖਾਓ
                }else if (x.Item1 == ENUM_EVENT.DURABILITY)
                { DurabilityEvent(batiments, x.Item2); // ਡਿਊਰੇਬਿਲਟੀ ਲਈ ਸਮਾਰਹੀਤ ਇਵੈਂਟ ਲਾਗੂ ਕਰੋ
                    if (x.Item2 < 0) t.Add("The village has lost " + Math.Abs(x.Item2) + " durability"); else t.Add("The village has gained " + x.Item2 + " durability"); // ਫਾਇਦਾ ਦਿਖਾਓ
                } } return string.Join("\n", t); // rt string.j 
        }
    }
}
    
