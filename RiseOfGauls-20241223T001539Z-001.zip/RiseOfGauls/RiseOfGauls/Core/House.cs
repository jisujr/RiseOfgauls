﻿namespace RiseOfGauls.Core;

public class House : Batimentix 
{
    public House() : base(10, 10, 2) { } // House ਕਲਾਸ ਦਾ ਕੰਸਟਰਕਟਰ, ਜੋ Batimentix ਕਲਾਸ ਦੇ ਕੰਸਟਰਕਟਰ ਨੂੰ ਕਾਲ ਕਰਦਾ ਹੈ
    /*******************
     * *****************
     * *****************
     *base(10, 10, 2) ਮਤਲਬ:10 - ਮੂਲ ਕੀਮਤ (cost)
     10 - ਮੈਕਸ ਡਿਊਰੇਬਿਲਟੀ (max durability)  2 - ਪੋਪੂਲੇਸ਼ਨ (population) ਜਿਹੜਾ ਗ੍ਰਾਮ ਵਿੱਚ 2 ਲੋਕਾਂ ਨੂੰ ਲਿਆਉਂਦਾ ਹੈ
     *******************
     * ****************
     * */
}