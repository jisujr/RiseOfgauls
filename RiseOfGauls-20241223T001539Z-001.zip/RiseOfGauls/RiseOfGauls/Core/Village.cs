﻿using System.Text;
using RiseOfGauls.Features;

namespace RiseOfGauls.Core;

public class Village
{
    public List<Batimentix> Batimentix;

    public Queue<Event> Events; 

//Village fun 
    public Village()
    {
        Batimentix = new List<Batimentix>(); } // sare batimentix di list veh 

    // first prp 
    public ChiefHut ChiefHut
    { get
        { foreach (var i in Batimentix)
            { if (i is ChiefHut p) //ethe vekhna ke jeh chiefhut list nahi veh
                { return p; } } throw new GaulsException("Err "); } // fir ethe koi proporty nahi ban sakhdi 

    }

    // ethe main population karna 
    public int Population
    {
        get { return ChiefHut.GetPopulation(); } set { ChiefHut.SetPopulation(value); } // ethe main chiefHut kita fir getter vaste teh setter vaste pop nu vich paya chiefhut deh 
    }

    // Freepop
    public int FreePopulation { get { return ChiefHut.GetFreePopulation(); } // ethe bas getter nu chief hut nal paya 
    }

    //level 
    public int Level { get { return ChiefHut.GetLevel(); } private set { ChiefHut.SetLevel(value); } // ethe main level for rt chief vaste fir st fir kita 
    }

    // vill random 
    public Village(Random random)
    {
        Batimentix = new List<Batimentix>();
        Events = new Queue<Event>();
        Batimentix.Add(new Bankix(random));
        Batimentix.Add(new ChiefHut());
    }

    // Bk bk
    public Bankix Bankix
    { get
        { foreach (var i in Batimentix) // ehte main rt kita vekhan lyi jeh ethe occ haigyi 
            { if (i is Bankix k) return k; } throw new GaulsException("Err"); // fir ethe main thrw kita 
        }
    }

    //My
    public int Money
    {
        get => Bankix.GetVillageMoney(); // Get vill kita 
        set { Bankix.SetVillageMoney(value); // Bnk ethe main set value kita 
        }
    }


    // Play Turn fun
    public bool PlayTurn(int amount, int risk, Stack<(Batimentix, bool)> actions)
    { return false;
    } // TODO




    // Public void Display Fun 

    public void DisplayStatus()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(new string('-', 50));
        Console.ResetColor();

        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Village Status:");
        Console.ResetColor();

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($"\tLevel: {Level}");
        Console.WriteLine($"\tPopulation: {Population}");
        Console.WriteLine($"\tFree Population: {FreePopulation}");
        Console.WriteLine($"\tMoney: {Money}");
        Console.ResetColor();
        Console.WriteLine("");

        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Buildings:");
        Console.ResetColor();

        foreach (Batimentix bat in Batimentix)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(
                $"\t{bat.GetType().Name} - Level: {bat.GetLevel()}, Durability: {bat.GetDurability()}, Cost: {bat.GetCost()}");
            Console.ResetColor();
        }

        Console.WriteLine("");

        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write("Next event: ");
        Console.ResetColor();

        if (Events.Count == 0)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("No events");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine(Events.Peek().Message);
        }

        Console.ResetColor();
        Console.WriteLine("");

        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine(new string('-', 50));
        Console.ResetColor();
    }

    public void PlayGame()
    {
        while (true)
        {
            Console.Clear();
            DisplayStatus();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("IT'S YOUR TURN!");
            Console.ResetColor();

            int amount;
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("Enter amount: ");
                Console.ResetColor();
                if (int.TryParse(Console.ReadLine(), out amount) && amount >= 0)
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid input. Please enter a non-negative integer.");
                Console.ResetColor();
            }

            int risk;
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("Enter risk: ");
                Console.ResetColor();
                if (int.TryParse(Console.ReadLine(), out risk) && risk >= 0)
                    break;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid input. Please enter a non-negative integer.");
                Console.ResetColor();
            }

            Stack<(Batimentix, bool)> actions = new Stack<(Batimentix, bool)>();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Available buildings:");
            Console.ResetColor();
            for (int i = 0; i < Batimentix.Count; i++)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(
                    $"\t{i}: {Batimentix[i].GetType().Name} (Level: {Batimentix[i].GetLevel()}, Durability: {Batimentix[i].GetDurability()})");
                Console.ResetColor();
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Enter actions (format: 'building_index upgrade/repair', type 'done' to finish):");
            Console.ResetColor();
            while (true)
            {
                string? input = Console.ReadLine();
                if (input!.ToLower() == "done")
                    break;

                string[] parts = input.Split(' ');
                if (parts.Length != 2)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid input format. Please use 'building_index upgrade/repair'.");
                    Console.ResetColor();
                    continue;
                }

                if (!int.TryParse(parts[0], out int buildingIndex) || buildingIndex < 0 ||
                    buildingIndex >= Batimentix.Count)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid building index. Please enter a valid index.");
                    Console.ResetColor();
                    continue;
                }

                bool upgrade;
                if (parts[1].ToLower() == "upgrade")
                {
                    upgrade = true;
                }
                else if (parts[1].ToLower() == "repair")
                {
                    upgrade = false;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid action. Please enter 'upgrade' or 'repair'.");
                    Console.ResetColor();
                    continue;
                }

                actions.Push((Batimentix[buildingIndex], upgrade));
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Enter new buildings to be created (format: 'building_type', type 'done' to finish):");
            Console.ResetColor();
            while (true)
            {
                string? input = Console.ReadLine();
                if (input!.ToLower() == "done")
                    break;

                Batimentix newBuilding;
                switch (input.ToLower())
                {
                    case "chiefhut":
                        newBuilding = new ChiefHut();
                        break;
                    case "bankix":
                        newBuilding = new Bankix(new Random());
                        break;
                    case "librarix":
                        newBuilding = new Librarix();
                        break;
                    case "house":
                        newBuilding = new House();
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid building type. Please enter a valid building type.");
                        Console.ResetColor();
                        continue;
                }

                Batimentix.Add(newBuilding);
            }

            if (PlayTurn(amount, risk, actions))
            {
                Console.ForegroundColor = ConsoleColor.Green;
                if (Level == 10)
                    Console.WriteLine("Game finished!");
                else
                    Console.WriteLine("Game over!");
                Console.ResetColor();
                break;
            }
        }
    }

//  Sav Evts

    public void SaveEvents(string path)
    {
        try
        {
            using (StreamWriter t = new StreamWriter(path)) // ਇਵੈਂਟਾਂ ਨੂੰ ਫਾਈਲ ਵਿੱਚ ਸੇਵ ਕਰਨਾ
            {
                foreach (var o in Events) // ethe main foreach kita 
                { string g = o.Message.Replace("\n", "\\n"); var l = g + "/"; var lstb = new List<string>(); // ethe main string kita 
                    foreach (var e in o.Events) // ethe main foreach kita 
                    { lstb.Add($"{e.Item1} {e.Item2}"); } l += string.Join("/", lstb); // ethe main add kita 
                    t.WriteLine(l); } } }catch (Exception i) { Console.WriteLine("Err " + i.Message); // ethe main writelin kita fir exp kita 
        }
    }


    
    
    //loads ets
    
    public void LoadEvents(string path)
    {
        try
        { 
            using (StreamReader d = new StreamReader(path))
            { 
                string n; // ethe main string kita fir 
                while ((n = d.ReadLine()) != null) // ethe main while kita fir mais if kita 
                { 
                    if (string.IsNullOrWhiteSpace(n)) continue; // fir main str use kita or int kita 
                    int t = n.IndexOf('<') + 1; 
                    int a = n.IndexOf('>'); // fir main ethe int kita 
                    if (t == 0 || a == -1) continue; // ethe main if kita 
                    string s = n.Substring(t, a - t).Replace("\\n", "\n"); 
                    string v = n.Substring(a + 1).TrimStart('/'); 
                    var z = new List<(ENUM_EVENT, int)>(); // ethe main str kita fir main str v kita 
                    foreach (var m in v.Split('/')) 
                    { var r = m.Split(' '); // ethe main foreach kita fir main if kita 
                        if (r.Length == 2 && PRT(r[0], out ENUM_EVENT p) && int.TryParse(r[1], out int l)) 
                        { z.Add((p, l)); } 
                    } var en = new Event(s, z.ToArray()); // ethe main if kita 
                    Events.Enqueue(en); 
                } 
            } 
        } 
        catch (Exception i) 
        { 
            Console.WriteLine("err " + i.Message); // ethe main events.enque kar ke exe kita 
        } 
    }
// eethe main fir manual varguy fun likhi kyu ki chaldi nahi si 
    private bool PRT(string n, out ENUM_EVENT t)
    {
        if (n == "MONEY") // ethe manual mapping kita 
        { t = ENUM_EVENT.MONEY; return true;  // rt true 
        } else if (n == "POPULATION") // if kita pop nal 
        { t = ENUM_EVENT.POPULATION; return true; // rt true 
        } else if (n == "DURABILITY") // if kita durability 
        { t = ENUM_EVENT.DURABILITY; return true;  // rt true
        } t = default; return false;  // rt fls kita
    } 

}
    
    
    
    

    
    
    





