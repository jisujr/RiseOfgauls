﻿namespace RiseOfGauls.Core;

public enum ENUM_EVENT
{
    MONEY, 
    POPULATION,
    DURABILITY
}
