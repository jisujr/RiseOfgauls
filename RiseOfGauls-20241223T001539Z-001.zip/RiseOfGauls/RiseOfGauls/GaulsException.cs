﻿namespace RiseOfGauls;

public class GaulsException : Exception
// Ethe main ik constructor banaya bina arg tu 
/* Public class GaulsException kita 
 ------------------------
 -----------------------
 -----------------------
 */

{ public GaulsException() : base("A problem happened in the village") { } 
    //Ethe main Dusera arg kita par ik string nal lol 
    
    /* Public class GaulsException ik string msg nal kita
 ------------------------
 -----------------------
 -----------------------
 */
    public GaulsException(string message) : base($"A problem happened in the village: {message}")
    { }
}